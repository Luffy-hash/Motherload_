package com.example.chatm1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import java.util.Calendar
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var messageViewModel: MessageViewModel

    private var messagesFragmaent: MessagesFragment? = null
    private var messageDetailFragment: MessageDetailFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        messageViewModel = ViewModelProvider(this).get(MessageViewModel::class.java)
        messageDetailFragment = supportFragmentManager.findFragmentById(R.id.mainNoteDetailFrag) as MessageDetailFragment?
        messagesFragmaent = supportFragmentManager.findFragmentById(R.id.mainNoteFrag) as MessagesFragment?
    }
}