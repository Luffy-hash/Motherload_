package com.example.chatm1

import java.util.Date

data class Message(val id:Int, val author:String,val msg:String,val date:Date) {
    //TODO ?
}