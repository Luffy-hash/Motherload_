package com.example.chatm1

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.util.*
import kotlin.collections.ArrayList

class MessagesRepo  private constructor() {

    companion object {
        @Volatile
        private var INSTANCE: MessagesRepo? = null

        fun getInstance(): MessagesRepo {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MessagesRepo().also { INSTANCE = it }
            }
        }
    }

    private val _messages = MutableLiveData<List<Message>>()
    val messages: LiveData<List<Message>> get() = _messages
    private val mListe = ArrayList<Message>()
    private var mAutoIncrement: Int = 0

    fun ajouteMessage(date: Date, author: String, msg: String) {
        //TODO
    }

    operator fun get(i: Int): Message? {
        return null // TODO
    }

    fun deleteMessageFromId(id: Int): Int {
        return -1 //TODO
    }

    fun size(): Int {
        return -1 //TODO
    }

    init {
        ajouteMessage(Calendar.getInstance().time,"L'elfe", "Bonjour bonjour")
        ajouteMessage(Calendar.getInstance().time,"L'ogre", "Broudaf, zog-zog ! ")
        ajouteMessage(Calendar.getInstance().time,"Le voleur", "Salut à vous, belle compagnie ! Vous m'attendiez ?")
        ajouteMessage(Calendar.getInstance().time,"Toto", "On va faire un contenu un peu plus long, pour voir comment ça passe sur tous les affichages. Hopla ! Et même encore un peu plus long histoire de dire. Après tout, normalement on a tout un écran pour l'afficher, donc on est bien large...")
    }
}